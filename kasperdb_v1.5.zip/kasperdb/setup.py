from setuptools import setup

setup(name='kasperdb',
      version='1.5',
      description='Simple database for your project. Local database!!!',
      packages=['kasperdb'],
      author_email='dimakukic1@gmail.com',
      zip_safe=False)
